﻿namespace Lms.Froms
{
    partial class FrmLogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            tbxUserName = new TextBox();
            tbxPassword = new TextBox();
            rdbtnSysMng = new RadioButton();
            rdbtnReader = new RadioButton();
            btnLogin = new Button();
            btnClose = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(70, 57);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(110, 31);
            label1.TabIndex = 0;
            label1.Text = "用户名：";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(70, 95);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(100, 31);
            label2.TabIndex = 1;
            label2.Text = "口  令：";
            // 
            // tbxUserName
            // 
            tbxUserName.Location = new Point(141, 53);
            tbxUserName.Name = "tbxUserName";
            tbxUserName.Size = new Size(134, 38);
            tbxUserName.TabIndex = 2;
            // 
            // tbxPassword
            // 
            tbxPassword.Location = new Point(142, 91);
            tbxPassword.Name = "tbxPassword";
            tbxPassword.PasswordChar = '*';
            tbxPassword.Size = new Size(134, 38);
            tbxPassword.TabIndex = 3;
            // 
            // rdbtnSysMng
            // 
            rdbtnSysMng.AutoSize = true;
            rdbtnSysMng.Checked = true;
            rdbtnSysMng.Location = new Point(56, 149);
            rdbtnSysMng.Name = "rdbtnSysMng";
            rdbtnSysMng.Size = new Size(135, 35);
            rdbtnSysMng.TabIndex = 4;
            rdbtnSysMng.TabStop = true;
            rdbtnSysMng.Text = "系统管理";
            rdbtnSysMng.UseVisualStyleBackColor = true;
            rdbtnSysMng.CheckedChanged += rdbtnSysMng_CheckedChanged;
            // 
            // rdbtnReader
            // 
            rdbtnReader.AutoSize = true;
            rdbtnReader.Location = new Point(207, 149);
            rdbtnReader.Name = "rdbtnReader";
            rdbtnReader.Size = new Size(135, 35);
            rdbtnReader.TabIndex = 5;
            rdbtnReader.Text = "读者借阅";
            rdbtnReader.UseVisualStyleBackColor = true;
            // 
            // btnLogin
            // 
            btnLogin.Location = new Point(48, 200);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(92, 36);
            btnLogin.TabIndex = 6;
            btnLogin.Text = "登录";
            btnLogin.UseVisualStyleBackColor = true;
            btnLogin.Click += btnLogin_Click;
            // 
            // btnClose
            // 
            btnClose.Location = new Point(216, 200);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(92, 36);
            btnClose.TabIndex = 7;
            btnClose.Text = "退出";
            btnClose.UseVisualStyleBackColor = true;
            btnClose.Click += btnClose_Click;
            // 
            // FrmLogin
            // 
            AutoScaleDimensions = new SizeF(14F, 31F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(359, 269);
            Controls.Add(btnClose);
            Controls.Add(btnLogin);
            Controls.Add(rdbtnReader);
            Controls.Add(rdbtnSysMng);
            Controls.Add(tbxPassword);
            Controls.Add(tbxUserName);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Margin = new Padding(4);
            Name = "FrmLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "登录窗口";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox tbxUserName;
        private TextBox tbxPassword;
        private RadioButton rdbtnSysMng;
        private RadioButton rdbtnReader;
        private Button btnLogin;
        private Button btnClose;
    }
}