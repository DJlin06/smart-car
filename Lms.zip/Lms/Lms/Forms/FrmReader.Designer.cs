﻿namespace Lms.Forms
{
    partial class FrmReader
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            图书类别管理ToolStripMenuItem = new ToolStripMenuItem();
            帮助ToolStripMenuItem = new ToolStripMenuItem();
            帮助ToolStripMenuItem1 = new ToolStripMenuItem();
            退出ToolStripMenuItem = new ToolStripMenuItem();
            联系管理员ToolStripMenuItem = new ToolStripMenuItem();
            图书管理ToolStripMenuItem = new ToolStripMenuItem();
            当前借阅图书与归还ToolStripMenuItem = new ToolStripMenuItem();
            预约图书ToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { 图书类别管理ToolStripMenuItem, 帮助ToolStripMenuItem, 图书管理ToolStripMenuItem, 当前借阅图书与归还ToolStripMenuItem, 预约图书ToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(9, 3, 0, 3);
            menuStrip1.Size = new Size(1257, 34);
            menuStrip1.TabIndex = 1;
            menuStrip1.Text = "menuStrip1";
            // 
            // 图书类别管理ToolStripMenuItem
            // 
            图书类别管理ToolStripMenuItem.Name = "图书类别管理ToolStripMenuItem";
            图书类别管理ToolStripMenuItem.Size = new Size(16, 28);
            // 
            // 帮助ToolStripMenuItem
            // 
            帮助ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { 帮助ToolStripMenuItem1, 退出ToolStripMenuItem, 联系管理员ToolStripMenuItem });
            帮助ToolStripMenuItem.Name = "帮助ToolStripMenuItem";
            帮助ToolStripMenuItem.Size = new Size(62, 28);
            帮助ToolStripMenuItem.Text = "系统";
            帮助ToolStripMenuItem.Click += 帮助ToolStripMenuItem_Click;
            // 
            // 帮助ToolStripMenuItem1
            // 
            帮助ToolStripMenuItem1.Name = "帮助ToolStripMenuItem1";
            帮助ToolStripMenuItem1.Size = new Size(270, 34);
            帮助ToolStripMenuItem1.Text = "帮助";
            // 
            // 退出ToolStripMenuItem
            // 
            退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            退出ToolStripMenuItem.Size = new Size(270, 34);
            退出ToolStripMenuItem.Text = "退出";
            退出ToolStripMenuItem.Click += 退出ToolStripMenuItem_Click;
            // 
            // 联系管理员ToolStripMenuItem
            // 
            联系管理员ToolStripMenuItem.Name = "联系管理员ToolStripMenuItem";
            联系管理员ToolStripMenuItem.Size = new Size(270, 34);
            联系管理员ToolStripMenuItem.Text = "联系管理员";
            // 
            // 图书管理ToolStripMenuItem
            // 
            图书管理ToolStripMenuItem.Name = "图书管理ToolStripMenuItem";
            图书管理ToolStripMenuItem.Size = new Size(98, 28);
            图书管理ToolStripMenuItem.Text = "图书借阅";
            图书管理ToolStripMenuItem.Click += 图书管理ToolStripMenuItem_Click;
            // 
            // 当前借阅图书与归还ToolStripMenuItem
            // 
            当前借阅图书与归还ToolStripMenuItem.Name = "当前借阅图书与归还ToolStripMenuItem";
            当前借阅图书与归还ToolStripMenuItem.Size = new Size(98, 28);
            当前借阅图书与归还ToolStripMenuItem.Text = "图书归还";
            // 
            // 预约图书ToolStripMenuItem
            // 
            预约图书ToolStripMenuItem.Name = "预约图书ToolStripMenuItem";
            预约图书ToolStripMenuItem.Size = new Size(98, 28);
            预约图书ToolStripMenuItem.Text = "图书预约";
            预约图书ToolStripMenuItem.Click += 预约图书ToolStripMenuItem_Click;
            // 
            // FrmReader
            // 
            AutoScaleDimensions = new SizeF(11F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1257, 635);
            Controls.Add(menuStrip1);
            Margin = new Padding(5, 4, 5, 4);
            Name = "FrmReader";
            Text = "图书管理-读者借阅";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem 图书类别管理ToolStripMenuItem;
        private ToolStripMenuItem 帮助ToolStripMenuItem;
        private ToolStripMenuItem 图书管理ToolStripMenuItem;
        private ToolStripMenuItem 帮助ToolStripMenuItem1;
        private ToolStripMenuItem 退出ToolStripMenuItem;
        private ToolStripMenuItem 联系管理员ToolStripMenuItem;
        private ToolStripMenuItem 当前借阅图书与归还ToolStripMenuItem;
        private ToolStripMenuItem 预约图书ToolStripMenuItem;
    }
}