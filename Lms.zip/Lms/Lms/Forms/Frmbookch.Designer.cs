﻿namespace Lms.Forms
{
    partial class Frmbookch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox10 = new TextBox();
            textBox7 = new TextBox();
            label7 = new Label();
            textBox6 = new TextBox();
            label6 = new Label();
            textBox5 = new TextBox();
            label5 = new Label();
            textBox9 = new TextBox();
            label9 = new Label();
            textBox8 = new TextBox();
            label8 = new Label();
            button2 = new Button();
            button1 = new Button();
            textBox11 = new TextBox();
            label11 = new Label();
            label10 = new Label();
            textBox4 = new TextBox();
            label4 = new Label();
            textBox3 = new TextBox();
            label3 = new Label();
            textBox2 = new TextBox();
            label2 = new Label();
            textBox1 = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // textBox10
            // 
            textBox10.Location = new Point(284, 623);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(244, 30);
            textBox10.TabIndex = 48;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(284, 455);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(244, 30);
            textBox7.TabIndex = 47;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(178, 455);
            label7.Name = "label7";
            label7.Size = new Size(100, 24);
            label7.TabIndex = 46;
            label7.Text = "图书类别：";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(284, 393);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(244, 30);
            textBox6.TabIndex = 45;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(178, 393);
            label6.Name = "label6";
            label6.Size = new Size(100, 24);
            label6.TabIndex = 44;
            label6.Text = "出版日期：";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(284, 331);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(244, 30);
            textBox5.TabIndex = 43;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(178, 331);
            label5.Name = "label5";
            label5.Size = new Size(102, 24);
            label5.TabIndex = 42;
            label5.Text = "出  版  社：";
            // 
            // textBox9
            // 
            textBox9.Location = new Point(284, 567);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(244, 30);
            textBox9.TabIndex = 41;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(178, 567);
            label9.Name = "label9";
            label9.Size = new Size(99, 24);
            label9.TabIndex = 40;
            label9.Text = "定       价：";
            // 
            // textBox8
            // 
            textBox8.Location = new Point(284, 511);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(244, 30);
            textBox8.TabIndex = 39;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(178, 511);
            label8.Name = "label8";
            label8.Size = new Size(102, 24);
            label8.TabIndex = 38;
            label8.Text = "索  引  号：";
            // 
            // button2
            // 
            button2.Location = new Point(425, 754);
            button2.Name = "button2";
            button2.Size = new Size(312, 58);
            button2.TabIndex = 37;
            button2.Text = "取消";
            button2.UseCompatibleTextRendering = true;
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(63, 754);
            button1.Name = "button1";
            button1.Size = new Size(312, 58);
            button1.TabIndex = 36;
            button1.Text = "修改图书";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(284, 683);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(244, 30);
            textBox11.TabIndex = 35;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(178, 683);
            label11.Name = "label11";
            label11.Size = new Size(100, 24);
            label11.TabIndex = 34;
            label11.Text = "内容简介：";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(178, 623);
            label10.Name = "label10";
            label10.Size = new Size(99, 24);
            label10.TabIndex = 33;
            label10.Text = "页       数：";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(284, 270);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(244, 30);
            textBox4.TabIndex = 32;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(178, 270);
            label4.Name = "label4";
            label4.Size = new Size(99, 24);
            label4.TabIndex = 31;
            label4.Text = "作       者：";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(284, 206);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(244, 30);
            textBox3.TabIndex = 30;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(178, 206);
            label3.Name = "label3";
            label3.Size = new Size(99, 24);
            label3.TabIndex = 29;
            label3.Text = "I  S  B  N：";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(284, 146);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(244, 30);
            textBox2.TabIndex = 28;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(178, 146);
            label2.Name = "label2";
            label2.Size = new Size(100, 24);
            label2.TabIndex = 27;
            label2.Text = "图书名称：";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(284, 83);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(244, 30);
            textBox1.TabIndex = 26;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(178, 83);
            label1.Name = "label1";
            label1.Size = new Size(100, 24);
            label1.TabIndex = 25;
            label1.Text = "图书编号：";
            // 
            // Frmbookch
            // 
            AutoScaleDimensions = new SizeF(11F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 895);
            Controls.Add(textBox10);
            Controls.Add(textBox7);
            Controls.Add(label7);
            Controls.Add(textBox6);
            Controls.Add(label6);
            Controls.Add(textBox5);
            Controls.Add(label5);
            Controls.Add(textBox9);
            Controls.Add(label9);
            Controls.Add(textBox8);
            Controls.Add(label8);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox11);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(textBox4);
            Controls.Add(label4);
            Controls.Add(textBox3);
            Controls.Add(label3);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Name = "Frmbookch";
            Text = "Frmbookch";
            Load += Frmbookch_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox10;
        private TextBox textBox7;
        private Label label7;
        private TextBox textBox6;
        private Label label6;
        private TextBox textBox5;
        private Label label5;
        private TextBox textBox9;
        private Label label9;
        private TextBox textBox8;
        private Label label8;
        private Button button2;
        private Button button1;
        private TextBox textBox11;
        private Label label11;
        private Label label10;
        private TextBox textBox4;
        private Label label4;
        private TextBox textBox3;
        private Label label3;
        private TextBox textBox2;
        private Label label2;
        private TextBox textBox1;
        private Label label1;
    }
}