﻿using BookMS;
using Lms.DataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lms.Forms
{
    public partial class Frmbooktype : Form
    {
        public Frmbooktype()
        {
            InitializeComponent();
            Table();
        }
        public void Table() //刷新视图
        {
            dataGridView1.Rows.Clear();
            string strSql = "select * from T_book_type";
            DataSet ds = SqlHelper.ExecuteDataSet(CommandType.Text, strSql);
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                dataGridView1.Rows.Add(dr[0].ToString(), dr[1].ToString());
            }

        }
        private void Frmbooktype_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Frmaddbooktype frmaddbooktype = new Frmaddbooktype();
            frmaddbooktype.ShowDialog();
            Table();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Frmbooktypech frmbooktypech = new Frmbooktypech(dataGridView1.SelectedRows[0].Cells[0].Value.ToString(), dataGridView1.SelectedRows[0].Cells[1].Value.ToString());
                frmbooktypech.ShowDialog();
                Table();
            }
            catch
            {
                MessageBox.Show("Error");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string book_type_id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                DialogResult ds = MessageBox.Show("确认是否删除", "信息提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (ds == DialogResult.OK)
                {
                    string sql = $"delete from T_book_type where 类别编号 = '{book_type_id}'";
                    Manage manage = new Manage();
                    if (manage.Execute(sql) > 0)
                    {
                        MessageBox.Show("删除成功");
                        Table();
                    }
                    else { MessageBox.Show("删除失败" + sql); }
                }
            }
            catch
            {
                MessageBox.Show("请先选择要删除的图书类别！", "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            label2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                dataGridView1.Rows.Clear();
                string strSql = $"select * from T_book_type where 类别编号 = '{textBox1.Text}'";
                DataSet ds = SqlHelper.ExecuteDataSet(CommandType.Text, strSql);
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    dataGridView1.Rows.Add(dr[0].ToString(), dr[1].ToString());
                }
            }
            else { MessageBox.Show("请输入要查询的类别编号"); }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
                dataGridView1.Rows.Clear();
                string strSql = $"select * from T_book_type where 类别名称 = '{textBox2.Text}'";
                DataSet ds = SqlHelper.ExecuteDataSet(CommandType.Text, strSql);
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    dataGridView1.Rows.Add(dr[0].ToString(), dr[1].ToString());
                }
            }
            else { MessageBox.Show("请输入要查询的类别名称"); }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Table();
            textBox1.Text = "";
            textBox2.Text = "";
        }
    }
}
