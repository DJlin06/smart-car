﻿using BookMS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Lms.Forms
{
    public partial class Frmbooktypech : Form
    {
        public Frmbooktypech()
        {
            InitializeComponent();
        }
        public Frmbooktypech(string text1, string text2)
        {
            InitializeComponent();
            book_type_id = textBox1.Text = text1;
            textBox2.Text = text2;
        }
        string book_type_id;

        private void button1_Click(object sender, EventArgs e)
        {
            
            try
            {
                 string sql = $"update T_book_type set 类别编号='{textBox1.Text}',类别名称 = '{textBox2.Text}' where 类别编号='{book_type_id}'";
            Manage manage = new Manage();
            if (manage.Execute(sql) > 0)
            {
                MessageBox.Show("修改成功！");
                this.Close();
            }
            }
            catch { MessageBox.Show("添加失败，请检查输入格式！"); }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
