﻿using BookMS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lms.Forms
{
    public partial class Frmbookch : Form
    {
        public Frmbookch()
        {
            InitializeComponent();
        }
        public Frmbookch(string text1, string text2, string text3, string text4, string text5, string text6, string text7, string text8, string text9, string text10, string text11)
        {
            InitializeComponent();
            bookid = textBox1.Text = text1;
            textBox2.Text = text2;
            textBox3.Text = text3;
            textBox4.Text = text4;
            textBox5.Text = text5;
            textBox6.Text = text6;
            textBox7.Text = text7;
            textBox8.Text = text8;
            textBox9.Text = text9;
            textBox10.Text = text10;
            textBox11.Text = text11;

        }
        string bookid;
        private void button1_Click(object sender, EventArgs e)
        {
            
            try
            {
                string sql = $"update T_book set 图书编号='{textBox1.Text}',图书名称 = '{textBox2.Text}',ISBN = '{textBox3.Text}',作者 = '{textBox4.Text}',出版社 = '{textBox5.Text}',出版日期 = '{textBox6.Text}',图书类别 = '{textBox7.Text}',索引号 = '{textBox8.Text}',定价 = '{textBox9.Text}',页数 = '{textBox10.Text}',内容简介 = '{textBox11.Text}' where 图书编号='{bookid}'";
            Manage manage = new Manage();
            if (manage.Execute(sql) > 0)
            {
                MessageBox.Show("修改成功！");
                this.Close();
            }
            }
            catch { MessageBox.Show("添加失败，请检查输入格式！"); }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Frmbookch_Load(object sender, EventArgs e)
        {

        }
    }
}
