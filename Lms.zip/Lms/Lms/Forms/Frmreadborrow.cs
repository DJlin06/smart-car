﻿using Lms.DataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lms.Forms
{
    public partial class Frmreadborrow : Form
    {
        public Frmreadborrow()
        {
            InitializeComponent();
            Table();
        }
        public void Table() //刷新视图
        {
            dataGridView1.Rows.Clear();
            string strSql = "select * from T_book";
            DataSet ds = SqlHelper.ExecuteDataSet(CommandType.Text, strSql);
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                dataGridView1.Rows.Add(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString(), dr[7].ToString(), dr[8].ToString(), dr[9].ToString(), dr[10].ToString());
            }

        }
        private void Frmreadborrow_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
