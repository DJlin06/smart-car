﻿namespace Lms.Forms
{
    partial class Frmreaderch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox10 = new TextBox();
            textBox7 = new TextBox();
            label7 = new Label();
            textBox6 = new TextBox();
            label6 = new Label();
            textBox5 = new TextBox();
            label5 = new Label();
            textBox9 = new TextBox();
            label9 = new Label();
            textBox8 = new TextBox();
            label8 = new Label();
            button2 = new Button();
            button1 = new Button();
            label10 = new Label();
            textBox4 = new TextBox();
            label4 = new Label();
            textBox3 = new TextBox();
            label3 = new Label();
            textBox2 = new TextBox();
            label2 = new Label();
            textBox1 = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // textBox10
            // 
            textBox10.Location = new Point(305, 577);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(244, 30);
            textBox10.TabIndex = 70;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(305, 409);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(244, 30);
            textBox7.TabIndex = 69;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(199, 409);
            label7.Name = "label7";
            label7.Size = new Size(100, 24);
            label7.TabIndex = 68;
            label7.Text = "电子邮箱：";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(305, 347);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(244, 30);
            textBox6.TabIndex = 67;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(199, 347);
            label6.Name = "label6";
            label6.Size = new Size(100, 24);
            label6.TabIndex = 66;
            label6.Text = "联系电话：";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(305, 285);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(244, 30);
            textBox5.TabIndex = 65;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(199, 285);
            label5.Name = "label5";
            label5.Size = new Size(99, 24);
            label5.TabIndex = 64;
            label5.Text = "单       位：";
            // 
            // textBox9
            // 
            textBox9.Location = new Point(305, 521);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(244, 30);
            textBox9.TabIndex = 63;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(199, 521);
            label9.Name = "label9";
            label9.Size = new Size(99, 24);
            label9.TabIndex = 62;
            label9.Text = "备       注：";
            // 
            // textBox8
            // 
            textBox8.Location = new Point(305, 465);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(244, 30);
            textBox8.TabIndex = 61;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(199, 465);
            label8.Name = "label8";
            label8.Size = new Size(100, 24);
            label8.TabIndex = 60;
            label8.Text = "注册日期：";
            // 
            // button2
            // 
            button2.Location = new Point(433, 657);
            button2.Name = "button2";
            button2.Size = new Size(312, 58);
            button2.TabIndex = 59;
            button2.Text = "取消";
            button2.UseCompatibleTextRendering = true;
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(71, 657);
            button1.Name = "button1";
            button1.Size = new Size(312, 58);
            button1.TabIndex = 58;
            button1.Text = "修改读者信息";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(199, 577);
            label10.Name = "label10";
            label10.Size = new Size(99, 24);
            label10.TabIndex = 57;
            label10.Text = "密       码：";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(305, 224);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(244, 30);
            textBox4.TabIndex = 56;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(199, 224);
            label4.Name = "label4";
            label4.Size = new Size(100, 24);
            label4.TabIndex = 55;
            label4.Text = "读者类别：";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(305, 160);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(244, 30);
            textBox3.TabIndex = 54;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(199, 160);
            label3.Name = "label3";
            label3.Size = new Size(99, 24);
            label3.TabIndex = 53;
            label3.Text = "性       别：";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(305, 100);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(244, 30);
            textBox2.TabIndex = 52;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(199, 100);
            label2.Name = "label2";
            label2.Size = new Size(99, 24);
            label2.TabIndex = 51;
            label2.Text = "姓       名：";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(305, 37);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(244, 30);
            textBox1.TabIndex = 50;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(199, 37);
            label1.Name = "label1";
            label1.Size = new Size(100, 24);
            label1.TabIndex = 49;
            label1.Text = "借书证号：";
            // 
            // Frmreaderch
            // 
            AutoScaleDimensions = new SizeF(11F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 753);
            Controls.Add(textBox10);
            Controls.Add(textBox7);
            Controls.Add(label7);
            Controls.Add(textBox6);
            Controls.Add(label6);
            Controls.Add(textBox5);
            Controls.Add(label5);
            Controls.Add(textBox9);
            Controls.Add(label9);
            Controls.Add(textBox8);
            Controls.Add(label8);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label10);
            Controls.Add(textBox4);
            Controls.Add(label4);
            Controls.Add(textBox3);
            Controls.Add(label3);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Name = "Frmreaderch";
            Text = "读者信息修改";
            Load += Frmreaderch_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox10;
        private TextBox textBox7;
        private Label label7;
        private TextBox textBox6;
        private Label label6;
        private TextBox textBox5;
        private Label label5;
        private TextBox textBox9;
        private Label label9;
        private TextBox textBox8;
        private Label label8;
        private Button button2;
        private Button button1;
        private Label label10;
        private TextBox textBox4;
        private Label label4;
        private TextBox textBox3;
        private Label label3;
        private TextBox textBox2;
        private Label label2;
        private TextBox textBox1;
        private Label label1;
    }
}