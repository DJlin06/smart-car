using Lms.Business;

namespace Lms.Froms
{
    public partial class FrmLogin : Form
    {
        /// <summary>
        /// ����ģʽ1ϵͳ������2�û�����
        /// </summary>
        public int mode;
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (tbxUserName.Text == String.Empty)
            {
                MessageBox.Show("�������û�����");
                return;
            }
            if (rdbtnSysMng.Checked)
                mode = 1;
            else if (rdbtnReader.Checked)
                mode = 2;
            else
            {
                MessageBox.Show("��ѡ���¼��ģʽ��");
                return;
            }
            string userName = tbxUserName.Text;
            string password = tbxPassword.Text;
            string result = string.Empty;
            BusLogin busLogin = new BusLogin();
            if (busLogin.Login(userName, password, mode, ref result))
            {
                DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show(result);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void rdbtnSysMng_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}