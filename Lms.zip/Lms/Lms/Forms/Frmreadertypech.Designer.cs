﻿namespace Lms.Forms
{
    partial class Frmreadertypech
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            button1 = new Button();
            textBox4 = new TextBox();
            label4 = new Label();
            textBox3 = new TextBox();
            label3 = new Label();
            textBox2 = new TextBox();
            label2 = new Label();
            textBox1 = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Location = new Point(425, 324);
            button2.Name = "button2";
            button2.Size = new Size(312, 58);
            button2.TabIndex = 47;
            button2.Text = "取消";
            button2.UseCompatibleTextRendering = true;
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(63, 324);
            button1.Name = "button1";
            button1.Size = new Size(312, 58);
            button1.TabIndex = 46;
            button1.Text = "修改读者类别";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(295, 256);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(244, 30);
            textBox4.TabIndex = 45;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(189, 256);
            label4.Name = "label4";
            label4.Size = new Size(100, 24);
            label4.TabIndex = 44;
            label4.Text = "借书期限：";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(295, 192);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(244, 30);
            textBox3.TabIndex = 43;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(189, 192);
            label3.Name = "label3";
            label3.Size = new Size(100, 24);
            label3.TabIndex = 42;
            label3.Text = "借书数量：";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(295, 132);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(244, 30);
            textBox2.TabIndex = 41;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(189, 132);
            label2.Name = "label2";
            label2.Size = new Size(100, 24);
            label2.TabIndex = 40;
            label2.Text = "类别名称：";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(295, 69);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(244, 30);
            textBox1.TabIndex = 39;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(189, 69);
            label1.Name = "label1";
            label1.Size = new Size(100, 24);
            label1.TabIndex = 38;
            label1.Text = "类别编号：";
            // 
            // Frmreadertypech
            // 
            AutoScaleDimensions = new SizeF(11F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox4);
            Controls.Add(label4);
            Controls.Add(textBox3);
            Controls.Add(label3);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Name = "Frmreadertypech";
            Text = "读者类别修改";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button button1;
        private TextBox textBox4;
        private Label label4;
        private TextBox textBox3;
        private Label label3;
        private TextBox textBox2;
        private Label label2;
        private TextBox textBox1;
        private Label label1;
    }
}