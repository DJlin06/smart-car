﻿namespace Lms.Forms
{
    partial class Frmbooktypech
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            button1 = new Button();
            textBox2 = new TextBox();
            label2 = new Label();
            textBox1 = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Location = new Point(297, 192);
            button2.Name = "button2";
            button2.Size = new Size(225, 58);
            button2.TabIndex = 36;
            button2.Text = "取消";
            button2.UseCompatibleTextRendering = true;
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(29, 192);
            button1.Name = "button1";
            button1.Size = new Size(217, 58);
            button1.TabIndex = 35;
            button1.Text = "修改图书类别";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(229, 119);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(178, 30);
            textBox2.TabIndex = 34;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(123, 119);
            label2.Name = "label2";
            label2.Size = new Size(100, 24);
            label2.TabIndex = 33;
            label2.Text = "类别名称：";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(229, 36);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(178, 30);
            textBox1.TabIndex = 32;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(123, 36);
            label1.Name = "label1";
            label1.Size = new Size(100, 24);
            label1.TabIndex = 31;
            label1.Text = "类别编号：";
            // 
            // Frmbooktypech
            // 
            AutoScaleDimensions = new SizeF(11F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(567, 283);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Name = "Frmbooktypech";
            Text = "修改图书类别";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button button1;
        private TextBox textBox2;
        private Label label2;
        private TextBox textBox1;
        private Label label1;
    }
}