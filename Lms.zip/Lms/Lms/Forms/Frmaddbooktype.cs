﻿using BookMS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Lms.Forms
{
    public partial class Frmaddbooktype : Form
    {
        public Frmaddbooktype()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != "" && textBox2.Text != "")
                {
                    Manage manage = new Manage();
                    string strSql = $"insert into T_book_type values ('{textBox1.Text}','{textBox2.Text}')";
                    int n = manage.Execute(strSql);
                    if (n > 0)
                    {
                        MessageBox.Show("添加成功！");
                        textBox1.Text = "";
                        textBox2.Text = "";
                        this.Close();
                    }
                    else { MessageBox.Show("添加失败！请联系负责人修改权限"); }
                }
                else
                {
                    MessageBox.Show("添加失败，输入不能为空");

                }
            }
            catch { MessageBox.Show("添加失败，请检查输入格式!"); }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }
    }
}
