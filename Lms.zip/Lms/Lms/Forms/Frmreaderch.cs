﻿using BookMS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Lms.Forms
{
    public partial class Frmreaderch : Form
    {
        public Frmreaderch()
        {
            InitializeComponent();
        }
        string readerid;
        public Frmreaderch(string text1, string text2, string text3, string text4, string text5, string text6, string text7, string text8, string text9, string text10)
        {
            InitializeComponent();
            readerid = textBox1.Text = text1;
            textBox2.Text = text2;
            textBox3.Text = text3;
            textBox4.Text = text4;
            textBox5.Text = text5;
            textBox6.Text = text6;
            textBox7.Text = text7;
            textBox8.Text = text8;
            textBox9.Text = text9;
            textBox10.Text = text10;

        }
        private void Frmreaderch_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            try
            {
                 string sql = $"update T_reader set 借书证号='{textBox1.Text}',姓名 = '{textBox2.Text}',性别 = '{textBox3.Text}',读者类别 = '{textBox4.Text}',单位 = '{textBox5.Text}',联系电话 = '{textBox6.Text}',电子邮箱 = '{textBox7.Text}',注册日期 = '{textBox8.Text}',备注 = '{textBox9.Text}',密码 = '{textBox10.Text}' where 借书证号='{readerid}'";
            Manage manage = new Manage();
            if (manage.Execute(sql) > 0)
            {
                MessageBox.Show("修改成功！");
                this.Close();
            }
            }
            catch { MessageBox.Show("添加失败，请检查输入格式！"); }
        }
    }
}
