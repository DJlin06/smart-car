﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lms.Forms
{
    public partial class FrmSysMng : Form
    {
        public FrmSysMng()
        {
            InitializeComponent();
        }

        private void 图书管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("这是图书管理菜单项！");
            Frmbook frmbookman = new Frmbook();
            frmbookman.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void FrmSysMng_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void label1_Click_3(object sender, EventArgs e)
        {

        }

        private void 帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("这是图书类别管理菜单项！");
            Frmbooktype frmbooktype = new Frmbooktype();
            frmbooktype.ShowDialog();
        }

        private void 读者管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("这是读者管理菜单项！");
            Frmread frmread = new Frmread();
            frmread.ShowDialog();

        }

        private void 读者类别管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("这是读者类别管理菜单项！");
            Frmreadertype frmreadertype = new Frmreadertype();
            frmreadertype.ShowDialog();
        }
    }
}
