﻿namespace Lms.Forms
{
    partial class FrmSysMng
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            图书管理ToolStripMenuItem = new ToolStripMenuItem();
            图书类别管理ToolStripMenuItem = new ToolStripMenuItem();
            读者管理ToolStripMenuItem = new ToolStripMenuItem();
            读者类别管理ToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { 图书管理ToolStripMenuItem, 图书类别管理ToolStripMenuItem, 读者管理ToolStripMenuItem, 读者类别管理ToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(9, 3, 0, 3);
            menuStrip1.Size = new Size(1257, 34);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // 图书管理ToolStripMenuItem
            // 
            图书管理ToolStripMenuItem.Name = "图书管理ToolStripMenuItem";
            图书管理ToolStripMenuItem.Size = new Size(98, 28);
            图书管理ToolStripMenuItem.Text = "图书管理";
            图书管理ToolStripMenuItem.Click += 图书管理ToolStripMenuItem_Click;
            // 
            // 图书类别管理ToolStripMenuItem
            // 
            图书类别管理ToolStripMenuItem.Name = "图书类别管理ToolStripMenuItem";
            图书类别管理ToolStripMenuItem.Size = new Size(134, 28);
            图书类别管理ToolStripMenuItem.Text = "图书类别管理";
            图书类别管理ToolStripMenuItem.Click += 帮助ToolStripMenuItem_Click;
            // 
            // 读者管理ToolStripMenuItem
            // 
            读者管理ToolStripMenuItem.Name = "读者管理ToolStripMenuItem";
            读者管理ToolStripMenuItem.Size = new Size(98, 28);
            读者管理ToolStripMenuItem.Text = "读者管理";
            读者管理ToolStripMenuItem.Click += 读者管理ToolStripMenuItem_Click;
            // 
            // 读者类别管理ToolStripMenuItem
            // 
            读者类别管理ToolStripMenuItem.Name = "读者类别管理ToolStripMenuItem";
            读者类别管理ToolStripMenuItem.Size = new Size(134, 28);
            读者类别管理ToolStripMenuItem.Text = "读者类别管理";
            读者类别管理ToolStripMenuItem.Click += 读者类别管理ToolStripMenuItem_Click;
            // 
            // FrmSysMng
            // 
            AutoScaleDimensions = new SizeF(11F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1257, 635);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Margin = new Padding(5, 4, 5, 4);
            Name = "FrmSysMng";
            SizeGripStyle = SizeGripStyle.Hide;
            Text = "图书管理-系统管理";
            Load += FrmSysMng_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem 图书管理ToolStripMenuItem;
        private ToolStripMenuItem 读者管理ToolStripMenuItem;
        private ToolStripMenuItem 图书类别管理ToolStripMenuItem;
        private ToolStripMenuItem 读者类别管理ToolStripMenuItem;
    }
}