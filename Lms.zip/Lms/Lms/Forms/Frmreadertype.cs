﻿using BookMS;
using Lms.DataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lms.Forms
{
    public partial class Frmreadertype : Form
    {
        public Frmreadertype()
        {
            InitializeComponent();
            Table();
        }
        public void Table() //刷新视图
        {
            dataGridView1.Rows.Clear();
            string strSql = "select * from T_reader_type";
            DataSet ds = SqlHelper.ExecuteDataSet(CommandType.Text, strSql);
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                dataGridView1.Rows.Add(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString());
            }
        }

        private void Frmreadertype_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Frmaddreadertype frmaddreadertype = new Frmaddreadertype();
            frmaddreadertype.ShowDialog();
            Table();
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            label2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Frmreadertypech frmreadertypech = new Frmreadertypech(dataGridView1.SelectedRows[0].Cells[0].Value.ToString(), dataGridView1.SelectedRows[0].Cells[1].Value.ToString(), dataGridView1.SelectedRows[0].Cells[2].Value.ToString(), dataGridView1.SelectedRows[0].Cells[3].Value.ToString());
                frmreadertypech.ShowDialog();
                Table();
            }
            catch
            {
                MessageBox.Show("Error");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string bookid = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                DialogResult ds = MessageBox.Show("确认是否删除", "信息提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (ds == DialogResult.OK)
                {
                    string sql = "delete from T_reader_type where 类别编号 = " + bookid;
                    Manage manage = new Manage();
                    if (manage.Execute(sql) > 0)
                    {
                        MessageBox.Show("删除成功");
                        Table();
                    }
                    else { MessageBox.Show("删除失败" + sql); }
                }
            }
            catch
            {
                MessageBox.Show("请先选择要删除的图书！", "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                dataGridView1.Rows.Clear();
                string strSql = $"select * from T_reader_type where 类别编号 = '{textBox1.Text}'";
                DataSet ds = SqlHelper.ExecuteDataSet(CommandType.Text, strSql);
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    dataGridView1.Rows.Add(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString());
                }
            }
            else { MessageBox.Show("请输入要查询的读者类别编号"); }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
                dataGridView1.Rows.Clear();
                string strSql = $"select * from T_reader_type where 类别名称 = '{textBox2.Text}'";
                DataSet ds = SqlHelper.ExecuteDataSet(CommandType.Text, strSql);
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    dataGridView1.Rows.Add(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString());
                }
            }
            else { MessageBox.Show("请输入要查询的读者类别名称"); }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Table();
            textBox1.Text = "";
            textBox2.Text = "";
        }
    }
}
