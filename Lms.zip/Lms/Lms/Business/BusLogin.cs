﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lms.DataAccess;
namespace Lms.Business
{
    public class BusLogin
    {
        public bool Login(string userName,string password,int mode,ref string result)
        {
            string dbPassword = string.Empty;
            if(DataLogin.Login(userName, mode, ref dbPassword, ref result))
            {
                if(password == dbPassword)
                    return true;
                else
                {
                    result = "用户或密码不正确！";
                    return false;
                }    
            }
            else
                return false;
        }
    }
}
