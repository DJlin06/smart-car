﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lms.DataAccess
{
    public class DataLogin
    {
        public static bool Login(string userName,int mode,ref string dbPassword,ref string result)
        {
            dbPassword=string.Empty;
            result=string.Empty;
            if (mode == 1)
            {
                string sqlStr = "select 密码 from t_user where 用户编号='" + userName + "'";
                DataSet ds = SqlHelper.ExecuteDataSet(CommandType.Text, sqlStr);
                if (ds.Tables[0].Rows.Count>0)
                {
                    dbPassword = ds.Tables[0].Rows[0]["密码"].ToString();
                    return true;
                }
                else
                {
                    result = "输入的用户不存在!";
                    return false;
                }
            }
            else
            {
                string sqlStr = "select 密码 from t_reader where 借书证号='" + userName + "'";
                DataSet ds = SqlHelper.ExecuteDataSet(CommandType.Text, sqlStr);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dbPassword = ds.Tables[0].Rows[0]["密码"].ToString();
                    return true;
                }
                else
                {
                    result = "输入的读者不存在!";
                    return false;
                }

            }
        }
    }
}
