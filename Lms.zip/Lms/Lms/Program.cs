using Lms.Forms;
using Lms.Froms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace BookMS
{
    class Manage
    {
        public SqlConnection connect()
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection sc = new SqlConnection(str);
            sc.Open();
            return sc;
        }
        public SqlCommand command(string sql)
        {
            SqlCommand cmd = new SqlCommand(sql, connect());
            return cmd;
        }
        public int Execute(string sql)
        {
            return command(sql).ExecuteNonQuery();
        }
        public SqlDataReader read(string sql)
        {
            return command(sql).ExecuteReader();
        }
    }

}

namespace Lms
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            FrmLogin frmLogin = new FrmLogin(); 
            if(frmLogin.ShowDialog() == DialogResult.OK)
            {
                if(frmLogin.mode== 1)
                    Application.Run(new FrmSysMng());
                else
                    Application.Run(new FrmReader());
            }
            else
                Application.Exit();
        }
    }
}